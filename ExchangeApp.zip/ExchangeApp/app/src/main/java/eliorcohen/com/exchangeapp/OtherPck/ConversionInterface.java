package eliorcohen.com.exchangeapp.OtherPck;

public interface ConversionInterface {

    void startProgressDialog();

    void stopProgressDialog();
}
